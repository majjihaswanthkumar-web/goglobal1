import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const message = (body?.message || '').toString().slice(0, 2000);
    const context = body?.context || {};
    if (!message) return Response.json({ error: 'Message is required' }, { status: 400 });

    // Pull relevant destination data to ground the assistant in real DB info.
    let destinationsContext = '';
    try {
      const list = await base44.asServiceRole.entities.Destination.list('-updated_date', 60);
      const names = (list || []).map((d) => `${d.name} (${d.city || ''}, ${d.country || ''}) [${(d.categories || []).join('/')}]`).join('; ');
      destinationsContext = names ? `Known destinations in the database: ${names}.` : '';
    } catch (e) {
      destinationsContext = '';
    }

    const tripContext = context.trip
      ? `Current trip: ${JSON.stringify(context.trip).slice(0, 1500)}`
      : '';

    const systemPrompt = `You are the WorldTrip Guide AI travel assistant. Help the user with travel questions, itinerary suggestions, cultural etiquette, food recommendations, and trip modifications. Be concise, friendly and practical. When recommending destinations, prefer ones that exist in the database when relevant. ${destinationsContext} ${tripContext}. If asked about currency or live prices, remind the user to use the currency converter and that prices are indicative.`;

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `${systemPrompt}\n\nUser: ${message}`,
    });

    return Response.json({ reply: typeof result === 'string' ? result : (result?.reply || JSON.stringify(result)) });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}