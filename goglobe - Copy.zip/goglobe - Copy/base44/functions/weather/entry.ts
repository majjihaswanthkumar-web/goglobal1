import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const WMO = (code) => {
  const map = { 113: 0, 116: 2, 119: 3, 122: 3, 143: 45, 176: 51, 179: 53, 182: 53, 185: 55, 200: 61, 227: 63, 230: 65, 248: 45, 260: 71, 263: 71, 266: 73, 281: 63, 284: 63, 293: 63, 296: 63, 299: 65, 302: 65, 305: 65, 308: 65, 311: 80, 314: 80, 317: 81, 320: 82, 323: 71, 326: 73, 329: 75, 332: 75, 335: 75, 338: 75, 350: 95, 353: 95, 356: 95, 359: 95, 362: 96, 365: 96, 368: 71, 371: 73, 374: 75, 377: 75, 386: 95, 389: 96, 392: 96, 395: 96 };
  return map[code] ?? 0;
};

export default async function(req: Request): Promise<Response> {
  try {
    const body = await req.json().catch(() => ({}));
    const lat = body?.lat;
    const lon = body?.lon;
    if (!lat || !lon) return Response.json({ error: 'lat and lon required' }, { status: 400 });

    // wttr.in: free, no key. Returns JSON with ?format=j1.
    const url = `https://wttr.in/${lat},${lon}?format=j1`;
    const res = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!res.ok) return Response.json({ error: `Weather service unavailable (${res.status})` }, { status: 502 });
    const data = await res.json();

    const cur = data.current_condition?.[0] || {};
    const days = data.weather || [];
    return Response.json({
      current: {
        temperature_2m: Number(cur.temp_C),
        weather_code: WMO(Number(cur.weatherCode)),
        wind_speed_10m: Number(cur.windspeedKmph),
      },
      daily: {
        time: days.map((d) => d.date),
        temperature_2m_max: days.map((d) => Number(d.maxtempC)),
        temperature_2m_min: days.map((d) => Number(d.mintempC)),
        precipitation_probability_max: days.map((d) => Number(d.hourly?.[4]?.chanceofrain || 0)),
      },
      timezone: data.nearest_area?.[0]?.areaName?.[0]?.value || 'auto',
      fetchedAt: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}