import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const CHUNK = 10;

function needsWork(d) {
  const desc = (d.description || '').trim();
  return desc.length < 420 || !(d.history || '').trim() || !(d.travelTips || '').trim();
}

const SCHEMA = {
  type: 'object',
  properties: {
    items: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          index: { type: 'integer' },
          description: { type: 'string' },
          history: { type: 'string' },
          travelTips: { type: 'string' },
        },
        required: ['index', 'description', 'history', 'travelTips'],
      },
    },
  },
  required: ['items'],
};

function buildPrompt(group) {
  const list = group
    .map((d, i) => {
      const where = [d.city, d.state, d.country].filter(Boolean).join(', ');
      const themes = (d.categories || []).join(', ') || 'general';
      return `${i + 1}. ${d.name} | Location: ${where || d.country || 'unknown'} | Themes: ${themes} | Existing note: ${d.description || 'none'}`;
    })
    .join('\n');

  return `You are writing destination guide copy for a travel planning app.

For EACH numbered destination below produce:
- "index": the number of the destination, exactly as listed.
- "description": ONE rich paragraph of 90 to 120 words. Evocative but factual: what the place is, why it matters, what a visitor sees and feels, plus one practical detail. Present tense, flowing prose, no bullet points, no statistics you are not certain of, and never open with "Welcome to".
- "history": 35 to 55 words of historical or cultural background.
- "travelTips": 30 to 45 words of practical advice about timing, crowds, access or etiquette.

Destinations:
${list}`;
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const body = await req.json().catch(() => ({}));
    const offset = Math.max(0, Math.min(2000, Number(body.offset) || 0));
    const limit = Math.max(1, Math.min(60, Number(body.limit) || 48));

    const all = await base44.asServiceRole.entities.Destination.list('created_date', 2000);
    const candidates = all.filter(needsWork);
    const slice = candidates.slice(offset, offset + limit);

    if (!slice.length) {
      return Response.json({ processed: 0, remaining: 0, message: 'All destinations are complete' });
    }

    const groups = [];
    for (let i = 0; i < slice.length; i += CHUNK) groups.push(slice.slice(i, i + CHUNK));

    const results = await Promise.allSettled(
      groups.map(async (group) => {
        const res = await base44.asServiceRole.integrations.Core.InvokeLLM({
          prompt: buildPrompt(group),
          response_json_schema: SCHEMA,
        });
        return { group, items: Array.isArray(res?.items) ? res.items : [] };
      })
    );

    const updates = [];
    let failed = 0;
    const errors = [];
    for (const r of results) {
      if (r.status !== 'fulfilled') {
        failed += 1;
        errors.push(String(r.reason?.message || r.reason));
        continue;
      }
      for (const item of r.value.items) {
        const idx = Number(item?.index) - 1;
        const d = r.value.group[idx];
        if (!d || !item?.description) continue;
        updates.push({
          id: d.id,
          description: String(item.description).trim(),
          history: String(item.history || '').trim() || d.history || '',
          travelTips: String(item.travelTips || '').trim() || d.travelTips || '',
        });
      }
    }

    if (updates.length) await base44.asServiceRole.entities.Destination.bulkUpdate(updates);

    return Response.json({
      processed: updates.length,
      attempted: slice.length,
      failedGroups: failed,
      errors,
      remaining: Math.max(0, candidates.length - updates.length),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}