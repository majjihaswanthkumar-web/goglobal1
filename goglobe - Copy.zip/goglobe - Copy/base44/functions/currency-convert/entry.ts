import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

export default async function(req: Request): Promise<Response> {
  try {
    const body = await req.json();
    const from = ((body?.from || 'USD') as string).toUpperCase();
    const to = ((body?.to || 'INR') as string).toUpperCase();
    const amount = Number(body?.amount ?? 1);

    const rawTargets = Array.isArray(body?.targets) ? body.targets : [];
    const targets = rawTargets
      .filter((t: unknown) => typeof t === 'string')
      .map((t: string) => t.toUpperCase())
      .slice(0, 12);

    // Free, no-key exchange rate API.
    const res = await fetch(`https://open.er-api.com/v6/latest/${from}`, {
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) return Response.json({ error: 'Currency service unavailable' }, { status: 502 });
    const data = await res.json();
    const rate = data?.rates?.[to];
    if (!rate) return Response.json({ error: `Rate for ${to} not found` }, { status: 400 });

    const rates: Record<string, number> = {};
    for (const code of targets) {
      const r = data?.rates?.[code];
      if (r) rates[code] = +(amount * r).toFixed(2);
    }

    return Response.json({
      from,
      to,
      rate,
      amount,
      converted: +(amount * rate).toFixed(2),
      updated: data.time_last_update_utc || new Date().toUTCString(),
      rates: Object.keys(rates).length ? rates : undefined,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}