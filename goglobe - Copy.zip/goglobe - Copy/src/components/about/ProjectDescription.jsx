import React from "react";
import { Compass, MapPin, CalendarPlus, Sparkles } from "lucide-react";

const FEATURES = [
  {
    icon: MapPin,
    title: "Destination library",
    text: "Curated places across India and the world, each with its history, culture, food, festivals, best season and practical travel tips.",
  },
  {
    icon: Compass,
    title: "Explore and map",
    text: "Search and filter by category or continent, then view every destination on an interactive map or a rotating 3D globe.",
  },
  {
    icon: CalendarPlus,
    title: "Trip planner",
    text: "Choose places, set your dates, budget and pace, and get a day-by-day itinerary with realistic travel and sightseeing times.",
  },
  {
    icon: Sparkles,
    title: "Travel tools",
    text: "Live weather, a currency converter, a phrase translator and an AI assistant that answers questions about your trip.",
  },
];

export default function ProjectDescription() {
  return (
    <section className="rounded-3xl border border-border/70 bg-card p-6 md:p-8 mt-6">
      <h2 className="font-display font-semibold text-2xl mb-3">About the project</h2>
      <div className="space-y-3 text-sm md:text-base text-muted-foreground leading-relaxed">
        <p>
          GoGlobe is an intelligent travel companion built to take the guesswork out of planning a trip. Instead of
          opening a dozen tabs, you can discover a place, understand its culture, check the weather and exchange rate, and
          turn it into a realistic itinerary in one place.
        </p>
        <p>
          Every destination in the library carries a full write-up: what makes it worth visiting, its history and
          architecture, the dishes to try, the crafts and festivals that define it, the languages spoken and the small
          details that make a first visit easier. From there, the planner arranges your selected places in a sensible order
          and builds a day-by-day schedule around how much time you actually have.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 mt-6">
        {FEATURES.map((f) => (
          <div key={f.title} className="rounded-2xl border border-border/60 bg-background p-4">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                <f.icon className="w-4 h-4" />
              </span>
              <h3 className="font-semibold text-sm text-foreground">{f.title}</h3>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">{f.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}